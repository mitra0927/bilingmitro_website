BilingMitro READY TO UPLOAD static website. Upload the contents of this folder to your hosting public_html/root. No GoDaddy Website Builder is required. The demo URL is https://youtu.be/qpNFV8B0T-w. The contact form uses mailto and therefore has no server-side processing; attachments are only selectable locally and are not transmitted by mailto.

## Contact form
The Contact Us form uses FormSubmit (https://formsubmit.co/) so the website remains static/serverless while supporting email delivery and file attachments. Submissions are sent to email2bmitra@gmail.com. On the first submission, FormSubmit may send an activation/confirmation email to that address; complete that activation before relying on the form in production. The form redirects to /thank-you/ after a successful submission.
