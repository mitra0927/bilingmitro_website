window.BILINGMITRO_DEMO_URL='https://youtu.be/qpNFV8B0T-w';
