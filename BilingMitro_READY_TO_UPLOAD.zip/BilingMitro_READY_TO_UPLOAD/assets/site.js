function setup(){
 const b=document.querySelector('.hamb');const n=document.querySelector('.links');if(b)b.onclick=()=>n.classList.toggle('open');
 const c=document.querySelector('.cookie');const cb=document.querySelector('.cookie button');if(cb)cb.onclick=()=>{c.style.display='none';localStorage.setItem('bm-cookie','1')};if(c&&localStorage.getItem('bm-cookie'))c.style.display='none';
 document.querySelectorAll('.faq-q').forEach(q=>q.onclick=()=>q.parentElement.classList.toggle('open'));
}document.addEventListener('DOMContentLoaded',setup);
